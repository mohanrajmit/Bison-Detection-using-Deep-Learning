# import the necessary packages
import os
# specify the shape of the inputs for our network
IMG_SHAPE = (255, 255, 1)
# specify the batch size and number of epochs
BATCH_SIZE = 8
EPOCHS = 100

# define the path to the base output directory
BASE_OUTPUT = "output\\faceModel(3.7)"
# use the base output path to derive the path to the serialized
# model along with training history plot
MODEL_PATH = os.path.sep.join([BASE_OUTPUT, "siamese_model"])
PLOT_PATH = os.path.sep.join([BASE_OUTPUT, "plot.png"])

## training in faceDetection_env
## testing in faceDetection_3.8